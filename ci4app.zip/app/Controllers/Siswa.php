<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Siswa extends BaseController
{
    // utama
	public function index()
	{
		// return view('dashboard');
        echo' KLIK LINK <a href="'.route_to('profil').'">Profil</a>';
	}

    public function profil()
	{
		// return view('dashboard');
        echo'HALO NAMA SAYA ADE';
	}

    public function data()
	{
		// return view('dashboard');
        echo' KLIK LINK <a href="'.route_to('data_diri').'">Data Diri</a>';
	}


    public function biodata()
	{
		return view('admin/user');
	}



    // url
    public function nama($nama,$umur,$alamat)
	{
		// return view('dashboard');
        echo'HALO NAMA SAYA '.$nama.' UMUR '.$umur.' ALAMAT '.$alamat.'';
	}

    // private
    protected function test(){
        echo'apakah ini akan muncul';
    }

}