<?php

namespace App\Controllers;

class Product extends BaseController
{
	public function index()
	{
        echo view('template/header');

		echo view('product/home');
        echo view('template/footer');
	}

    public function page()
	{
		echo view('template/header');
		echo view('content');
		echo view('template/footer');
	}

	// menampilkan data string biasa
	public function catalog(){

		$data=[
			'product'=>'Redmi Note 9',
			'merk'=>'Xiaomi',
			'kode'=>'10',
			'buatan'=>'China'
		];
		return view('product/home',$data);
	}

	// menampilkan data array

	public function barang(){
		$data=[
			'product'=>[
				'Redmi Note 9',
				'Redmi Note 10',
				'Redmi Note 11',
				'Redmi Note 12',
			],
			'merk'=>'Xiaomi',
			'kode'=>[
				'10',
				'11',
				'13',
				'01',
			],
			'buatan'=>'China'
		];
		return view('product/home',$data);
	}


}