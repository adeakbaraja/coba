<?php

namespace App\Controllers\Akses;

use App\Controllers\BaseController;

class Akses extends BaseController
{
	public function index()
	{
		return view('akses/login');
	}

}