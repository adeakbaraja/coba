<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Product</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css">
</head>
<body>
<div class="container">
<br>
<br>
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Product</th>
            </tr>
        </thead>
        <?php foreach ($product as $key => $value) {?>
            <tbody>
            <tr>
                <td><?= $value?></td>
            </tr>
        </tbody>
       <?php }?>
       
       
    </table>

    <br>
    <br>

    <table id="example2" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Kode</th>
            </tr>
        </thead>
        <?php foreach ($kode as $key => $value) {?>
            <tbody>
            <tr>
                <td><?= $value?></td>
            </tr>
        </tbody>
       <?php }?>
       
       
    </table>
</div>



    



<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
    <script>
    $(document).ready(function() {
    $('#example').DataTable();
} );

$(document).ready(function() {
    $('#example2').DataTable();
} );
    </script>
</body>
</html>